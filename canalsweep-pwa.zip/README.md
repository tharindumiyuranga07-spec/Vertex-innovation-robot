# CanalSweep PWA

Files: index.html, manifest.json, service-worker.js, icon-192.png, icon-512.png

## Test on your computer
Service workers need http://localhost or https. Do not double-click index.html.
1. Open a terminal in this folder.
2. Run: python3 -m http.server 8000
3. Open http://localhost:8000 in Chrome.
4. DevTools > Application > Manifest / Service Workers to check them.

## Publish with GitHub Pages (free, HTTPS)
1. Create a GitHub repository (for example canalsweep).
2. Upload all five files to the repository root.
3. Settings > Pages > Source: Deploy from a branch > main > / (root) > Save.
4. After a minute your app is at https://YOUR-NAME.github.io/canalsweep/

## Install on the phone
Open the link in Chrome on Android, then menu > Install app (or Add to Home screen).

## When you change a file
Edit the file, then change CACHE in service-worker.js (v1 to v2) so phones update.
